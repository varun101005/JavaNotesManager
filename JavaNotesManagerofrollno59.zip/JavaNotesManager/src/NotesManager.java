import java.io.*;
import java.util.*;

public class NotesManager {
    static final String NOTES_DIR = "notes";

    public static void main(String[] args) {
        File dir = new File(NOTES_DIR);
        if (!dir.exists()) dir.mkdirs();

        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n=== Java Notes Manager ===");
            System.out.println("1. Create JavaFile1.txt");
            System.out.println("2. Display JavaFile1.txt");
            System.out.println("3. Create JavaFile2.txt");
            System.out.println("4. Copy content from JavaFile1.txt to JavaFile2.txt");
            System.out.println("5. Analyze JavaFile1.txt");
            System.out.println("6. Display JavaFile2.txt");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();  // consume newline

            switch (choice) {
                case 1 -> createJavaFile1(sc);
                case 2 -> displayNote("JavaFile1.txt");
                case 3 -> createJavaFile2();
                case 4 -> copyContent("JavaFile1.txt", "JavaFile2.txt");
                case 5 -> analyzeNote("JavaFile1.txt", sc);
                case 6 -> displayNote("JavaFile2.txt");
                case 7 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice.");
            }

        } while (choice != 7);

        sc.close();
    }

    static void createJavaFile1(Scanner sc) {
        File file = new File(NOTES_DIR + "/JavaFile1.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            System.out.println("Creating JavaFile1.txt.");
            System.out.println("Type lines below. Type 'END' to finish:");

            String line;
            while (!(line = sc.nextLine()).equals("END")) {
                writer.write(line);
                writer.newLine();
            }

            System.out.println("JavaFile1.txt saved.");
        } catch (IOException e) {
            System.out.println("Error creating JavaFile1.txt: " + e.getMessage());
        }
    }

    static void createJavaFile2() {
        String[] lines = {
            "This is the first line in this JavaFile2.txt file."
        };
        writeToFile("JavaFile2.txt", lines);
        System.out.println("JavaFile2.txt created.");
    }

    static void writeToFile(String fileName, String[] lines) {
        try {
            FileWriter writer = new FileWriter(NOTES_DIR + "/" + fileName);
            for (String line : lines) {
                writer.write(line + "\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static void displayNote(String fileName) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(NOTES_DIR + "/" + fileName));
            String line;
            System.out.println("\n--- " + fileName + " ---");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("File not found.");
        }
    }

    static void copyContent(String fromFile, String toFile) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(NOTES_DIR + "/" + toFile, true));
            BufferedReader reader = new BufferedReader(new FileReader(NOTES_DIR + "/" + fromFile));
            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line + "\n");
            }
            writer.close();
            reader.close();
            System.out.println("Content copied from " + fromFile + " to " + toFile);

            displayNote(toFile);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static void analyzeNote(String fileName, Scanner sc) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(NOTES_DIR + "/" + fileName));
            int charCount = 0, wordCount = 0, lineCount = 0, wordMatchCount = 0;
            String line;
            int lineNumber = 0;

            System.out.print("Enter the word to search: ");
            String searchWord = sc.nextLine().toLowerCase();

            System.out.println("\nAnalyzing " + fileName + "...\n");

            while ((line = reader.readLine()) != null) {
                lineNumber++;
                lineCount++;
                charCount += line.length();
                String[] words = line.split("\\s+");
                wordCount += words.length;

                for (String w : words) {
                    String cleanedWord = w.toLowerCase().replaceAll("[^a-z0-9]", "");
                    if (cleanedWord.equals(searchWord)) {
                        wordMatchCount++;
                        System.out.println("Found '" + searchWord + "' on line " + lineNumber);
                    }
                }
            }

            reader.close();

            System.out.println("\nTotal Characters: " + charCount);
            System.out.println("Total Words: " + wordCount);
            System.out.println("Total Lines: " + lineCount);
            System.out.println("Occurrences of '" + searchWord + "': " + wordMatchCount);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
